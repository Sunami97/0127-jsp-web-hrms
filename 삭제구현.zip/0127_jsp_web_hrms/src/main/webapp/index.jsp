<%@ page contentType="text/html; charset=utf-8"%>
<!DOCTYPE html>
<html>
<head>
<title>人事管理 プログラム</title>
</head>
<body>
	人事管理 プログラム
	
	<form action="move.do" >
		<button type="submit" name="cmd" value="adminForm" >관리창</button>
	</form>
	
</body>
</html>