package user.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.command.CommandHandler;

public class UserMoveHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {
		// TODO Auto-generated method stub
		if(req.getParameter("cmd").equalsIgnoreCase("adminForm")) {
			return "WEB-INF/view/adminForm.jsp";
		} else if(req.getParameter("cmd").equalsIgnoreCase("register")){
			return "WEB-INF/view/userRegisterForm.jsp";
		} else {
			return "WEB-INF/view/adminForm.jsp";
		}
		
	}

}
