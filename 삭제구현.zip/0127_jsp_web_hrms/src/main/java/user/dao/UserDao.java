package user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import jdbc.JdbcUtil;
import user.dto.UserDto;

public class UserDao {
	public void insert(Connection conn,	UserDto userDto) throws SQLException {
		PreparedStatement pstmt = null;
		
		try { 
			pstmt = conn.prepareStatement("insert into user_tbl values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, userDto.getUserId());
			pstmt.setString(2, userDto.getPassword());
			pstmt.setString(3, userDto.getName());
			pstmt.setString(4, userDto.getEmail());
			pstmt.setString(5, userDto.getPhone());
			pstmt.setDate(6, java.sql.Date.valueOf(userDto.getBirthDate()));
			pstmt.setDate(7, java.sql.Date.valueOf(userDto.getJoinDate()));
			pstmt.setDate(8, java.sql.Date.valueOf(userDto.getRetireDate()));
			pstmt.setString(9, userDto.getPosition());
			pstmt.setInt(10, userDto.getDepartmentId());
			pstmt.setString(11, userDto.getIsAdmin());
			pstmt.setString(12, userDto.getEmpStatus());
			pstmt.setString(13, userDto.getWorkStatus());
			pstmt.setString(14, userDto.getLoginStatus());
			pstmt.executeUpdate();
			
		}finally {
			JdbcUtil.close(pstmt);
			
		}
		
	}public List<UserDto> selectList(Connection conn,String keyWord, String keyField) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		if(keyWord =="" || keyWord==null) {
			try {
			pstmt = conn.prepareStatement("Select * from user_tbl");
			rs = pstmt.executeQuery();
			List<UserDto> result = new ArrayList<>();
			while(rs.next()) {
				result.add(convertUser(rs));
				
			}
			
			return result;
			}finally 
			{
				JdbcUtil.close(rs);
				JdbcUtil.close(pstmt);
			}
		} else 
		{
		
		try { 
			pstmt = conn.prepareStatement("Select * from user_tbl where " + keyField + " = ?");
			pstmt.setString(1, keyWord);
			rs = pstmt.executeQuery();
			List<UserDto> result = new ArrayList<>();
			
			while(rs.next()) {
				result.add(convertUser(rs));
			}
			return result;
		}finally 
		{
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}
	}
	private UserDto convertUser(ResultSet rs) throws SQLException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	    String birthDate = null;
	    Date birth = rs.getDate("birth_date");
	    if (birth != null) birthDate = sdf.format(birth);

	    String joinDate = null;
	    Date join = rs.getDate("join_date");
	    if (join != null) joinDate = sdf.format(join);

	    String retireDate = null;
	    Date retire = rs.getDate("retire_date");
	    if (retire != null) retireDate = sdf.format(retire);
	    
		return new UserDto(	rs.getString("user_id"),
						rs.getString("password"),
						rs.getString("name"),
						rs.getString("email"),
						rs.getString("phone"),
						birthDate,
						joinDate,
						retireDate,
						rs.getString("position"),
						rs.getInt("department_id"),
						rs.getString("is_admin"),
						rs.getString("emp_status"),
						rs.getString("work_status"),
						rs.getString("login_status"));
	}
	public void Delete(Connection conn, String[] userId) throws SQLException {
		if (userId != null && userId.length > 0) {
		    PreparedStatement pstmt = null;
		    try {
		        conn.setAutoCommit(false); // 트랜잭션 시작
		        pstmt = conn.prepareStatement("delete from user_tbl where user_id = ?");
		        
		        for (int i = 0; i < userId.length; i++) {
		            pstmt.setString(1, userId[i]);
		            pstmt.executeUpdate();
		        }
		        
		        conn.commit(); // 성공 시 커밋
		    } catch (Exception e) {
		        JdbcUtil.rollback(conn); // 실패 시 롤백
		        e.printStackTrace();
		    } finally {
		      JdbcUtil.close(conn);
		    }
		}
	}
	
}

