<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ include file="common/header.jsp" %>
<%@ page import="myPage.model.UserDepartmentDTO"%>
<%
    // [서버에서 user 객체 받기!]
    // Controller/Handler에서 setAttribute("user", ...)로 user 정보 전달받음
    // Controller（ハンドラー）から setAttribute で user オブジェクトが届くよ！
    UserDepartmentDTO userDepartment = (UserDepartmentDTO) request.getAttribute("user");

    // [로그인 or 세션 없으면 안내]
    // 로그인(セッション) 정보 없으면 안내문 띄우고 종료
    if (userDepartment == null) {
%>
<h2>개인정보</h2>
<p style="color: red;">
    회원 정보가 없습니다.<br> 세션이 만료되었거나, 로그인 정보가 올바르지 않습니다.<br>
    <a href="<%=request.getContextPath()%>/login.jsp" style="color: #007bff;">로그인 페이지로 이동</a>
</p>
<%
    // [아래 코드 더 이상 실행X (return)]
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
    <title>개인정보</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- [FontAwesome: 아이콘 폰트 라이브러리(カメラなど)] -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        /* [페이지 전체 폰트와 배경 (ページ全体のフォント・背景)] */
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f7fa;
        }
        /* [프로필 카드 레이아웃 (プロフィールカードのレイアウト)] */
        .profile-card {
            display: flex;        /* 横並び (flex) */
            max-width: 700px;
            margin: 40px auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.11);
            overflow: hidden;
            min-height: 340px;
            padding: 50px;
        }
        /* [왼쪽: 사진, 이름, 부서/직책, 버튼 (左側：写真・名前・部署・ボタン)] */
        .profile-left {
            background: #f0f4fa;
            padding: 36px 18px 24px 18px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 230px;
            width: 230px;
            position: relative;
        }
        /* [프로필 사진 (プロフィール画像)] */
        .profile-img-wrapper {
            position: relative;
            width: 140px;
            height: 140px;
            margin-bottom: 16px;
        }
        .profile-img {
            width: 140px;
            height: 140px;
            border-radius: 50%;    /* 동그랗게丸く */
            object-fit: cover;
            background: #d6e0f7;
            box-shadow: 0 2px 10px #dde3ee;
        }
        /* [사진변경 버튼: 사진 오른쪽 아래 겹침 (画像変更ボタン)] */
        .profile-img-edit {
            position: absolute;
            right: 6px;
            bottom: 8px;
            background: #386cf4;
            color: #fff;
            border-radius: 50%;
            width: 32px; height: 32px;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 1px 5px rgba(0,0,0,.13);
            border: 2px solid #fff;
            cursor: pointer;
            z-index: 2;
            font-size: 15px;
            transition: background 0.16s;
        }
        .profile-img-edit:hover { background: #2749ad; }
        .profile-img-edit input[type="file"] {
            position: absolute;
            left: 0; top: 0; width: 100%; height: 100%;
            opacity: 0; cursor: pointer;
        }
        /* [이름/부서/직책 텍스트 (名前/部署/役職)] */
        .profile-name {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 10px;
            color: #283047;
            text-align: center;
        }
        .profile-pos {
            color: #71829b;
            font-size: 16px;
            text-align: center;
        }
        /* [수정 버튼 스타일 (修正ボタン)] */
        .btn-group {
            width: 100%;
            margin-top: 38px;
            display: flex;
            justify-content: flex-start;
            align-items: flex-end;
        }
        .my-btn {
            width: 100%;
            background: #386cf4;
            color: #fff;
            border: none;
            padding: 14px 0;
            border-radius: 19px;
            font-size: 16px;
            cursor: pointer;
            font-weight: 500;
            transition: background 0.18s;
        }
        .my-btn:hover {
            background: #003bb8;
        }
        /* [오른쪽: 정보 테이블 (右側：情報テーブル)] */
        .profile-right {
            flex: 1;
            padding: 38px 32px;
            min-width: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .profile-table {
            width: 100%;
            border-collapse: collapse;
            background: none;
        }
        /* [테이블 스타일 (テーブルスタイル)] */
        .profile-table th, .profile-table td {
            padding: 11px 10px 10px 0;
            border-bottom: 1px solid #e0e3ea !important;
            text-align: left;
            font-size: 16px;
            color: #353f50;
        }
        .profile-table th {
            background: none;
            width: 104px;
            color: #7682a0;
            font-weight: 600;
        }
        .profile-table tr:last-child td, .profile-table tr:last-child th {
            border-bottom: 1px solid #e0e3ea !important;
        }
        /* [모바일 대응 (レスポンシブ)] */
        @media (max-width: 700px) {
            .profile-card {
                flex-direction: column;
                width: 98vw;
                min-width: 0;
            }
            .profile-left, .profile-right {
                width: 100% !important;
                min-width: 0;
                padding: 24px 14px;
                justify-content: center;
            }
            .btn-group { margin-top: 26px; }
            .profile-img-wrapper, .profile-img { width: 100px; height: 100px; }
            .profile-img-edit { width: 22px; height: 22px; font-size: 11px; right: 2px; bottom: 2px;}
            .profile-table th, .profile-table td { font-size: 14px; }
        }
    </style>
    <script>
        // [사진 선택하면 미리보기! (画像プレビュー)]
        function previewProfileImg(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profilePreview').src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</head>
<body>
    <div class="profile-card">
        <div class="profile-left">
            <div class="profile-img-wrapper">
                <!-- [프로필 기본 이미지, 나중에 DB연동도 가능!] -->
                <img src="https://cdn-icons-png.flaticon.com/512/1946/1946429.png"
                     alt="프로필" id="profilePreview"
                     class="profile-img" />
                <!-- [사진 변경 버튼: 클릭하면 파일 선택창 (画像選択ボタン)] -->
                <label class="profile-img-edit" title="사진 변경">
                    <i class="fa-solid fa-camera"></i>
                    <input type="file" name="profileImg" accept="image/*" onchange="previewProfileImg(this)">
                </label>
            </div>
            <!-- [이름 (名前)] -->
            <div class="profile-name"><%=userDepartment.getName()%></div>
            <!-- [부서/직책 (部署/役職)] -->
            <div class="profile-pos">
                <%=userDepartment.getDepartmentName() == null ? "" : userDepartment.getDepartmentName()%>
                <% if(userDepartment.getPosition() != null && !userDepartment.getPosition().isEmpty()) { %>
                    / <%= userDepartment.getPosition() %>
                <% } %>
            </div>
            <!-- [수정 버튼 (修正ボタン)] -->
            <div class="btn-group">
                <a href="<%=request.getContextPath()%>/mypageEditForm.do" style="width:100%;">
                    <button type="button" class="my-btn">수정</button>
                </a>
            </div>
        </div>
        <div class="profile-right">
            <!-- [유저 정보 테이블 (ユーザー情報テーブル)] -->
            <table class="profile-table">
                <tr><th>아이디</th><td><%=userDepartment.getUserId()%></td></tr>
                <tr><th>이름</th><td><%=userDepartment.getName()%></td></tr>
                <tr><th>부서</th><td><%=userDepartment.getDepartmentName() == null ? "" : userDepartment.getDepartmentName()%></td></tr>
                <tr><th>직책</th><td><%=userDepartment.getPosition() == null ? "" : userDepartment.getPosition()%></td></tr>
                <tr><th>이메일</th><td><%=userDepartment.getEmail() == null ? "" : userDepartment.getEmail()%></td></tr>
                <tr><th>전화번호</th><td><%=userDepartment.getPhone() == null ? "" : userDepartment.getPhone()%></td></tr>
                <tr><th>생년월일</th><td><%=userDepartment.getBirthDate() == null ? "" : userDepartment.getBirthDate().toString()%></td></tr>
                <tr><th>입사일</th><td><%=userDepartment.getJoinDate() == null ? "" : userDepartment.getJoinDate().toString()%></td></tr>
                <tr><th>퇴사일</th><td><%=userDepartment.getRetireDate() == null ? "" : userDepartment.getRetireDate().toString()%></td></tr>
                <%-- 관리자 계정만 노출 (管理者の場合だけ) --%>
                <% if ("Y".equals(userDepartment.getIsAdmin())) { %>
                    <tr><th>관리자여부</th><td>예</td></tr>
                <% } %>
                <tr><th>근로상태</th><td><%=userDepartment.getEmpStatus() == null ? "" : userDepartment.getEmpStatus()%></td></tr>
                <tr><th>근무상태</th><td><%=userDepartment.getWorkStatus() == null ? "" : userDepartment.getWorkStatus()%></td></tr>
                <tr><th>로그인상태</th><td><%="Y".equals(userDepartment.getLoginStatus()) ? "예" : "아니오"%></td></tr>
            </table>
        </div>
    </div>
    <%@ include file="common/footer.jsp" %>
</body>
</html>
