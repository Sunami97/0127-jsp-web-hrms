package user.command;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.command.CommandHandler;
import user.dto.UserDto;
import user.service.UserInsertService;

public class UserInsertHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/adminForm.jsp";
	private UserInsertService userService = new UserInsertService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {
		if(req.getMethod().equalsIgnoreCase("get")) {
			return processForm(req, res);
		}else if(req.getMethod().equalsIgnoreCase("post")) {
			return processSubmit(req,res);
		}else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}
	private String processForm(HttpServletRequest req, HttpServletResponse res) {
		return FORM_VIEW;
	}
	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws NumberFormatException, Exception {
		UserInsertService userRequest = new UserInsertService(); 
		UserDto userDto = new UserDto(
				req.getParameter("userId"),
				req.getParameter("password"),
				req.getParameter("name"),
				req.getParameter("email"),
				req.getParameter("phone"),
				req.getParameter("birthDate"),
				req.getParameter("joinDate"),
				req.getParameter("position"),
				Integer.parseInt(req.getParameter("departmentId")),
				req.getParameter("isAdmin"),
				req.getParameter("empStatus"),
				req.getParameter("workStatus"),
				req.getParameter("loginStatus")
				);
		
		
		
		
		
		
		userRequest.serviceInsert(userDto);
		return "WEB-INF/view/adminForm.jsp";
	}
}
